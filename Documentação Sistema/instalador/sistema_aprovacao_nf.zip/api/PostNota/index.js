/**
 * Sistema de Aprovacao de NF - PostNota
 *
 * Recebe nova NF via POST JSON com PDF em base64.
 * Sobe PDF pra SharePoint Pendentes + cria item na lista NotasFiscais.
 *
 * Body JSON esperado:
 *   {
 *     fornecedorCNPJ: "00.000.000/0001-00",  // ou CPF
 *     fornecedorRazao: "Razao Social",
 *     numero: "12345",
 *     serie: "1",
 *     valor: 1500.00,
 *     vencimento: "2026-06-30",
 *     unidade: "RJ",       // SP|RJ|ES
 *     diretoria: "Suprimentos",  // do fornecedor
 *     negociadoCom: null,  // email do gestor financeiro quando vencimento < D+5
 *     descricao: "Servicos de manutencao",
 *     fileBase64: "data:application/pdf;base64,JVBERi0xLjcK...",
 *     fileName: "NF-12345.pdf"
 *   }
 *
 * Retorna:
 *   200 { ok: true, id, urlPDF, aprovador: {email, nome} }
 *   400 { error: "..." }
 *   409 { error: "Duplicidade", duplicada: {...} }
 *   500 { error: "...", diag: {...} }
 */

require('isomorphic-fetch');
const { notificar } = require('../shared/notificar');
const { registrar: auditRegistrar } = require('../shared/auditLog');
const { getUser } = require('../shared/auth');
const crypto = require('crypto');
const { ClientSecretCredential } = require('@azure/identity');
const { Client } = require('@microsoft/microsoft-graph-client');
const { TokenCredentialAuthenticationProvider } =
  require('@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials');

const LIST_NOTAS = 'PRONEP-NF-NotasFiscais';
const LIST_DIRETORIAS = 'PRONEP-NF-Diretorias';
const cache = { siteId: null, driveId: null, listNotasId: null, listDirId: null, colMap: null, colTypes: null, colMapCachedAt: 0 };

// =============================================================================
// EXTRACAO DA CHAVE DE ACESSO DA NF-e (44 digitos)
// =============================================================================
// Usado pra deteccao forte de duplicidade — chave de acesso eh o identificador
// LEGAL unico de uma NF-e no Brasil (esquema da SEFAZ). Se duas NFs tem a mesma
// chave, sao a MESMA NF.
//
// Estrategia: usar pdf-parse pra extrair texto, depois regex /\d{44}/ pra achar
// uma sequencia continua de 44 digitos. Tambem aceita formatos com espacos/pontos
// (NF-e impressa as vezes formata em blocos de 4 digitos separados).
//
// Retorna a chave (string de 44 digitos puros) ou null se nao encontrar.
// Falha silenciosamente: NFS-e municipais NAO tem chave de 44 digitos —
// dependem de duplicidade por hash + CNPJ+numero, que sao os outros mecanismos.
async function extrairChaveAcesso(pdfBuffer) {
  try {
    if (!pdfBuffer || !Buffer.isBuffer(pdfBuffer)) return null;
    let pdfParse;
    try { pdfParse = require('pdf-parse'); }
    catch (e) {
      console.warn('[extrairChaveAcesso] pdf-parse nao instalado:', e.message);
      return null;
    }
    const data = await pdfParse(pdfBuffer);
    const texto = (data && data.text) || '';
    if (!texto) return null;

    // Normaliza: tira espacos, pontos e quebras de linha que podem partir a chave
    // (NF-e impressa muitas vezes mostra "1234 5678 9012 ... ").
    // Procura primeiro o padrao continuo (44 digitos seguidos).
    let m = texto.match(/\b(\d{44})\b/);
    if (m && m[1]) return m[1];

    // Tentativa 2: chave fragmentada com espacos/pontos. Concatena dgts apos limpar.
    const semSeparadores = texto.replace(/[\s.-]/g, '');
    m = semSeparadores.match(/\d{44}/);
    if (m && m[0]) return m[0];

    return null;
  } catch (e) {
    console.warn('[extrairChaveAcesso] erro:', e && e.message);
    return null;
  }
}

// =============================================================================
// PADRAO DE NOMENCLATURA DOS PDFs (Pronep)
// =============================================================================
// Pendentes: {DataVenc}_{NumNF}_{Fornec30}_{UF}_{Valor}.pdf
//   Ex.: 2026-06-15_12345_OLA-TECNOLOGIA-EM-SAUDE-LTDA_RJ_15000,00.pdf
// Aprovadas: idem + _APROVADA_{DataAprov}
//   Ex.: 2026-06-15_12345_OLA-TECNOLOGIA-EM-SAUDE-LTDA_RJ_15000,00_APROVADA_2026-05-28.pdf
// Detalhes:
//   - Valor com VIRGULA decimal (nao ponto - evita confusao com extensao .pdf)
//   - Numero SEM zeros a esquerda (00987 vira 987 - facilita rastrear duplicidade)
//   - Fornecedor: uppercase ASCII, max 30 chars, hifens no lugar de espacos/especiais
function buildPdfFileName(opts) {
  var numero = opts.numero, fornecedor = opts.fornecedor, unidade = opts.unidade;
  var valor = opts.valor, vencimento = opts.vencimento, sufixoAprovada = opts.sufixoAprovada;
  var dv = String(vencimento || '').substring(0, 10) || 'sem-data';
  var forn = String(fornecedor || 'NF')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30)
    .replace(/-+$/g, '') || 'NF';
  // Numero: tira nao-alfanumericos e remove zeros a esquerda
  // (facilita rastrear duplicidade: usuario busca "987" e acha mesmo que tenha sido "00987")
  var numClean = String(numero || '').replace(/[^A-Za-z0-9]/g, '');
  var numFinal = /^\d+$/.test(numClean) ? (numClean.replace(/^0+/, '') || '0') : (numClean || 'SN');
  var uf = String(unidade || '').toUpperCase().slice(0, 2) || 'XX';
  var valorNum = (typeof valor === 'number' ? valor : Number(valor)) || 0;
  // Valor com virgula decimal (evita confusao com extensao .pdf)
  var v = valorNum.toFixed(2).replace('.', ',');
  var nome = dv + '_' + numFinal + '_' + forn + '_' + uf + '_' + v;
  if (sufixoAprovada) nome += '_APROVADA_' + sufixoAprovada;
  return nome + '.pdf';
}
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutos

// Descobre mapping displayName -> internalName das colunas da lista NotasFiscais
// IMPORTANTE: filtra colunas read-only (LinkTitle, Edit, ItemChildCount, etc) e colunas
// de sistema (_UIVersionString, _ComplianceTag, etc) pra nao bagunçar o mapeamento
async function getColumnMap(client, siteId, listId) {
  const age = Date.now() - (cache.colMapCachedAt || 0);
  if (cache.colMap && age < CACHE_TTL_MS) return cache.colMap;
  const resp = await client
    .api(`/sites/${siteId}/lists/${listId}/columns`)
    .get();
  const map = {};
  const types = {};
  for (const col of (resp.value || [])) {
    if (!col.displayName || !col.name) continue;
    if (col.readOnly === true) continue;
    if (col.hidden === true) continue;
    if (col.name.startsWith('_')) continue;
    if (['LinkTitle','LinkTitleNoMenu','Edit','DocIcon','ItemChildCount',
         'FolderChildCount','AppAuthor','AppEditor','Attachments'].includes(col.name)) continue;
    map[col.displayName] = col.name;
    // Captura o TIPO da coluna pra logica especifica
    // Possiveis: text, number, dateTime, boolean, choice, hyperlinkOrPicture,
    //            personOrGroup, currency, calculated, lookup, ...
    // ORDEM IMPORTANTE: tipos especificos primeiro porque o SP API as vezes retorna
    // multiplas propriedades (ex: col.text presente mesmo em coluna Hyperlink).
    // text fica como fallback.
    let detectedType = 'text';
    if (col.hyperlinkOrPicture)  detectedType = 'hyperlink';
    else if (col.currency)       detectedType = 'currency';
    else if (col.dateTime)       detectedType = 'dateTime';
    else if (col.number)         detectedType = 'number';
    else if (col.boolean)        detectedType = 'boolean';
    else if (col.choice)         detectedType = 'choice';
    else if (col.personOrGroup)  detectedType = 'person';
    else if (col.calculated)     detectedType = 'calculated';
    else if (col.lookup)         detectedType = 'lookup';
    else if (col.text)           detectedType = 'text';

    // OVERRIDE HARDCODED: Graph API as vezes nao retorna hyperlinkOrPicture truthy pra
    // colunas Hyperlink criadas via UI classica. Forcar hyperlink pelo nome conhecido.
    if (col.name === 'UrlPDF' || col.name === 'UrlPDFAprovado'
        || col.displayName === 'UrlPDF' || col.displayName === 'UrlPDFAprovado') {
      detectedType = 'hyperlink';
    }

    types[col.name] = detectedType;
    // Debug: guardar as propriedades RAW dessas 2 colunas pra inspecionar via diag
    if (col.name === 'UrlPDF' || col.name === 'UrlPDFAprovado') {
      if (!cache.colRaw) cache.colRaw = {};
      cache.colRaw[col.name] = Object.keys(col);
    }
  }
  cache.colMap = map;
  cache.colTypes = types;
  cache.colMapCachedAt = Date.now();
  return map;
}

// Constroi o objeto fields com internalNames corretos
function buildFieldsObject(colMap, data) {
  const fields = {};
  for (const [displayName, value] of Object.entries(data)) {
    const internal = colMap[displayName] || displayName;
    fields[internal] = value;
  }
  return fields;
}

// Formata valor de acordo com o tipo da coluna no SharePoint
function formatByType(internalName, value) {
  const t = (cache.colTypes && cache.colTypes[internalName]) || 'text';
  if (value === null || value === undefined || value === '') return undefined;
  switch (t) {
    case 'hyperlink': {
      const url = String(value);
      // Extrai filename pra Description (Graph rejeita Description vazia em alguns casos)
      let descr = 'Ver PDF';
      try {
        const decoded = decodeURIComponent(url);
        const m = decoded.match(/\/([^\/?#]+\.pdf)(?:[?#]|$)/i);
        if (m && m[1]) descr = m[1].substring(0, 100);
      } catch (e) {}
      return { Url: url, Description: descr };
    }
    case 'currency':
    case 'number': {
      const num = Number(value);
      return isNaN(num) ? undefined : num;
    }
    case 'boolean':
      return value === true || value === 'true' || value === 'Sim';
    case 'dateTime':
      return value;
    default:
      return String(value);
  }
}

async function getGraphClient() {
  const tenantId = process.env.AAD_TENANT_ID;
  const clientId = process.env.AAD_CLIENT_ID;
  const clientSecret = process.env.AAD_CLIENT_SECRET;
  if (!tenantId || !clientId || !clientSecret) throw new Error('AAD_* incompletas');
  const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
  const authProvider = new TokenCredentialAuthenticationProvider(credential, {
    scopes: ['https://graph.microsoft.com/.default']
  });
  return Client.initWithMiddleware({ authProvider });
}

async function resolveSiteAndDrive(client) {
  if (cache.siteId && cache.driveId && cache.listNotasId && cache.listDirId) return cache;
  const host = process.env.SHAREPOINT_SITE_HOSTNAME;
  const path = process.env.SHAREPOINT_SITE_PATH;
  if (!host || !path) throw new Error('SHAREPOINT_* incompletas');
  const siteResp = await client.api(`/sites/${host}:${path}`).get();
  cache.siteId = siteResp.id;
  const driveResp = await client.api(`/sites/${cache.siteId}/drive`).get();
  cache.driveId = driveResp.id;
  // List IDs
  const lists = await client.api(`/sites/${cache.siteId}/lists`).get();
  for (const l of lists.value || []) {
    if (l.displayName === LIST_NOTAS) cache.listNotasId = l.id;
    if (l.displayName === LIST_DIRETORIAS) cache.listDirId = l.id;
  }
  if (!cache.listNotasId) throw new Error(`Lista '${LIST_NOTAS}' nao encontrada`);
  if (!cache.listDirId)   throw new Error(`Lista '${LIST_DIRETORIAS}' nao encontrada`);
  return cache;
}

function readClientPrincipal(req) {
  const header = req.headers && req.headers['x-ms-client-principal'];
  if (!header) return null;
  try {
    const decoded = Buffer.from(header, 'base64').toString('utf-8');
    return JSON.parse(decoded);
  } catch (e) { return null; }
}

// Resolve quem eh o aprovador a partir da matriz Diretorias
async function resolveAprovador(client, siteId, listDirId, unidade, diretoria) {
  const chave = `${unidade}|${diretoria}`;
  const resp = await client
    .api(`/sites/${siteId}/lists/${listDirId}/items?expand=fields&$top=200`)
    .get();
  const found = (resp.value || []).find(item => (item.fields || {}).Title === chave);
  if (!found) return null;
  const f = found.fields || {};
  return { email: f.field_3 || '', nome: f.field_4 || '' };
}

// Gera proximo numero auto-sequencial (00001, 00002, ...) consultando max(NumeroNF)
// entre items com NumeroAutogerado=true. Pagina via @odata.nextLink pra cobrir
// listas grandes (Graph limita 999 por pagina).
// Race condition: 2 submissoes simultaneas podem pegar o mesmo numero. No contexto
// Pronep (1-2 submissoes/min no pico) o risco eh aceitavel; se ocorrer, sao 2 NFs
// com mesmo numero auto que admin pode renumerar no SP UI.
async function gerarProximoNumeroAuto(client, siteId, listNotasId, colMap) {
  const colNumero = (colMap && colMap['NumeroNF']) || 'NumeroNF';
  const colAuto   = (colMap && colMap['NumeroAutogerado']) || 'NumeroAutogerado';
  let maxNum = 0;
  let nextUrl = `/sites/${siteId}/lists/${listNotasId}/items?expand=fields&$top=999`;
  let pages = 0;
  while (nextUrl && pages < 20) {  // hard stop ~20k itens
    pages++;
    const r = await client.api(nextUrl).get();
    for (const it of (r.value || [])) {
      const f = it.fields || {};
      const auto = f[colAuto];
      // SP boolean retorna true/false; se a coluna foi criada como text (fallback),
      // pode vir como 'true' ou '1'. Aceita os 3.
      const isAuto = (auto === true || auto === 'true' || auto === '1' || auto === 1);
      if (!isAuto) continue;
      const numStr = String(f[colNumero] || f.NumeroNF || '');
      const num = parseInt(numStr, 10);
      if (!isNaN(num) && num > maxNum) maxNum = num;
    }
    const nextLink = r['@odata.nextLink'];
    if (nextLink) {
      const idx = nextLink.indexOf('/v1.0/');
      nextUrl = idx >= 0 ? nextLink.substring(idx + 5) : null;
    } else nextUrl = null;
  }
  const proximo = maxNum + 1;
  return String(proximo).padStart(5, '0');
}

// Checa duplicata: chave_acesso OU hash OU (CNPJ + numero) OU (CNPJ + valor + vencimento).
// A ultima regra so eh disparada quando o numero veio AUTOGERADO no upload novo —
// nesse caso CNPJ+numero nao tem como bater (cada auto gera numero novo), entao
// confiamos em CNPJ+valor+vencimento pra pegar reenvio do mesmo "reembolso/rescisao".
// IGNORA NFs com status 'Rejeitada' — usuario pode corrigir e reenviar.
async function verificaDuplicata(client, siteId, listNotasId, colMap, hash, cnpj, numero, serie, chaveAcesso, valor, vencimento, isNumeroAutogerado) {
  const resp = await client
    .api(`/sites/${siteId}/lists/${listNotasId}/items?expand=fields&$top=999`)
    .get();
  // Resolve internal names dinamicamente; se nao tiver no map, cai pros displayNames padrao
  const colStatus  = (colMap && colMap['Status']) || 'Status';
  const colHash    = (colMap && colMap['HashSHA256']) || 'HashSHA256';
  const colCNPJ    = (colMap && colMap['CNPJFornecedor']) || 'CNPJFornecedor';
  const colNumero  = (colMap && colMap['NumeroNF']) || 'NumeroNF';
  const colChave   = (colMap && colMap['ChaveAcesso']) || 'ChaveAcesso';
  const colValor   = (colMap && colMap['Valor']) || 'Valor';
  const colVenc    = (colMap && colMap['DataVencimento']) || 'DataVencimento';
  const vencNorm   = vencimento ? String(vencimento).substring(0, 10) : '';

  for (const item of (resp.value || [])) {
    const f = item.fields || {};
    const itemStatus = f[colStatus] || f.Status || '';
    // Pula NFs rejeitadas — usuario pode reenviar com a NF corrigida
    if (String(itemStatus).toLowerCase() === 'rejeitada') continue;

    const itemHash  = f[colHash]   || f.HashSHA256     || '';
    const itemDoc   = f[colCNPJ]   || f.CNPJFornecedor || '';
    const itemNum   = f[colNumero] || f.NumeroNF       || '';
    const itemChave = f[colChave]  || f.ChaveAcesso    || '';

    // Criterio MAIS FORTE: chave de acesso de 44 digitos (identificador legal unico).
    if (chaveAcesso && itemChave && String(chaveAcesso).replace(/\D/g,'') === String(itemChave).replace(/\D/g,'')) {
      return { motivo: 'chave_acesso', notaId: item.id, status: itemStatus, chave: itemChave };
    }
    if (hash && itemHash && hash === itemHash) {
      return { motivo: 'hash', notaId: item.id, status: itemStatus };
    }
    if (cnpj && numero && itemDoc === cnpj && itemNum === numero) {
      return { motivo: 'cnpj_numero', notaId: item.id, status: itemStatus };
    }
    // REGRA EXTRA: numero veio autogerado no upload novo → confia em CNPJ+valor+venc.
    // Catches: usuario refaz upload do mesmo PDF (re-exportado) sem numero formal.
    if (isNumeroAutogerado && cnpj && valor && vencNorm && itemDoc === cnpj) {
      const itemValor = Number(f[colValor] || f.Valor || 0);
      const itemVenc  = String(f[colVenc] || f.DataVencimento || '').substring(0, 10);
      if (Math.abs(itemValor - Number(valor)) < 0.01 && itemVenc === vencNorm) {
        return { motivo: 'cnpj_valor_vencimento', notaId: item.id, status: itemStatus };
      }
    }
  }
  return null;
}

module.exports = async function (context, req) {
  const diag = { step: 'start' };
  try {
    diag.step = 'parse_body';
    const body = req.body || {};
    const {
      fornecedorCNPJ, fornecedorRazao, numero, serie, valor, vencimento,
      unidade, diretoria, negociadoCom, descricao, observacao,
      fileBase64, fileName, solicitanteEmail
    } = body;

    // Validacao
    if (!fornecedorCNPJ) return ctxErr(context, 400, 'fornecedorCNPJ obrigatorio');
    // numero NAO eh mais obrigatorio - quando vazio, geramos sequencial automatico
    // (caso de reembolso, rescisao, etc onde nao existe NF formal numerada)
    if (typeof valor !== 'number' || valor <= 0) return ctxErr(context, 400, 'valor invalido');
    if (!vencimento)     return ctxErr(context, 400, 'vencimento obrigatorio');
    if (!unidade)        return ctxErr(context, 400, 'unidade obrigatoria');
    if (!diretoria)      return ctxErr(context, 400, 'diretoria obrigatoria');
    if (!fileBase64)     return ctxErr(context, 400, 'fileBase64 obrigatorio');
    if (!fileName)       return ctxErr(context, 400, 'fileName obrigatorio');

    diag.step = 'decode_base64';
    // Remove o prefixo "data:application/pdf;base64,"
    const base64 = fileBase64.includes(',') ? fileBase64.split(',')[1] : fileBase64;
    const pdfBuffer = Buffer.from(base64, 'base64');
    if (pdfBuffer.length > 6 * 1024 * 1024) {
      return ctxErr(context, 400, 'Arquivo excede 6 MB (' + (pdfBuffer.length/1024/1024).toFixed(2) + ' MB)');
    }
    diag.fileSize = pdfBuffer.length;

    diag.step = 'hash';
    const hash = crypto.createHash('sha256').update(pdfBuffer).digest('hex');
    diag.hash = hash;

    diag.step = 'principal';
    // Resolve solicitante em CASCATA pra evitar 'desconhecido':
    //   1. getUser(req)               — Easy Auth ou Teams SSO (oficial)
    //   2. principal.userDetails      — Easy Auth raw (cookie SWA)
    //   3. body.solicitanteEmail      — front envia como hint (sessão JS)
    //   4. 'desconhecido@pronep.com.br' (ULTIMO RECURSO)
    const usr = await getUser(req);
    const principal = readClientPrincipal(req);
    const principalEmail = (principal && principal.userDetails) || '';
    const validEmail = function(e) {
      return typeof e === 'string' && e.length > 5 && e.includes('@') && !e.startsWith('desconhecido');
    };
    var submitterEmail, submitterSource, user;
    if (usr && validEmail(usr.email)) {
      submitterEmail = usr.email;
      submitterSource = 'shared_auth_' + (usr.source || 'unknown');
      user = { oid: usr.oid || '', email: usr.email, name: usr.name || usr.email };
    } else if (validEmail(principalEmail)) {
      submitterEmail = principalEmail.toLowerCase();
      submitterSource = 'easy_auth_raw';
      user = { oid: (principal && principal.userId) || '', email: submitterEmail, name: principalEmail };
    } else if (validEmail(solicitanteEmail)) {
      submitterEmail = String(solicitanteEmail).toLowerCase();
      submitterSource = 'body_hint';
      // OID sintetico pra audit log nao silenciar (precisa de oid pra gravar)
      user = { oid: 'body-' + Date.now(), email: submitterEmail, name: submitterEmail };
    } else {
      submitterEmail = 'desconhecido@pronep.com.br';
      submitterSource = 'desconhecido';
      // OID sintetico pra audit log nao silenciar - sem isso o caso "desconhecido"
      // some da Trilha de Auditoria e cega o diagnostico (guard em auditLog.js linha 80).
      user = { oid: 'anon-' + Date.now(), email: submitterEmail, name: submitterEmail };
    }
    diag.submitter = submitterEmail;
    diag.submitterSource = submitterSource;
    diag.submitterDebug = {
      getUserOk: !!(usr && usr.email),
      principalEmailOk: !!validEmail(principalEmail),
      bodyEmailOk: !!validEmail(solicitanteEmail),
      bodyEmailValueLen: typeof solicitanteEmail === 'string' ? solicitanteEmail.length : -1,
      bodyEmailRaw: typeof solicitanteEmail === 'string' ? String(solicitanteEmail).slice(0, 80) : null,
      hasEasyAuthHeader: !!(req.headers && (req.headers['x-ms-client-principal'] || req.headers['X-MS-CLIENT-PRINCIPAL'])),
      hasTeamsToken: !!(req.headers && (req.headers['x-teams-token'] || req.headers['X-Teams-Token'])),
      hasAuthHeader: !!(req.headers && (req.headers.authorization || req.headers.Authorization)),
      userAgent: (req.headers && (req.headers['user-agent'] || req.headers['User-Agent'])) || null,
      authError: req._authError || null
    };
    // Log estruturado pro Application Insights tambem (caso audit log falhe)
    if (context && context.log) {
      context.log('[PostNota submitter resolved]', JSON.stringify({
        source: submitterSource,
        email: submitterEmail,
        debug: diag.submitterDebug
      }));
    }

    diag.step = 'graph';
    const client = await getGraphClient();
    const { siteId, driveId, listNotasId, listDirId } = await resolveSiteAndDrive(client);
    diag.siteId = siteId;

    diag.step = 'aprovador';
    const aprovador = await resolveAprovador(client, siteId, listDirId, unidade, diretoria);
    if (!aprovador || !aprovador.email) {
      return ctxErr(context, 400, `Nao encontrado aprovador para ${unidade}|${diretoria}`);
    }
    diag.aprovador = aprovador.email;

    // Resolve colMap ANTES da verificacao de duplicata — precisamos do internal name
    // do Status pra filtrar NFs rejeitadas corretamente
    diag.step = 'discover_columns';
    const colMap = await getColumnMap(client, siteId, listNotasId);
    diag.colMap = colMap;
    diag.colTypes = cache.colTypes;
    diag.colRaw = cache.colRaw;

    diag.step = 'extrair_chave_acesso';
    const chaveAcesso = await extrairChaveAcesso(pdfBuffer);
    diag.chaveAcesso = chaveAcesso || '(nao encontrada — pode ser NFS-e municipal)';

    // AUTO-NUMERACAO: se usuario nao informou numero (reembolso/rescisao/etc),
    // gera proximo sequencial 00001, 00002, ...
    diag.step = 'auto_numerar';
    var numeroFinal = numero;
    var foiAutogerado = false;
    if (!numero || !String(numero).trim()) {
      numeroFinal = await gerarProximoNumeroAuto(client, siteId, listNotasId, colMap);
      foiAutogerado = true;
      diag.numeroGerado = numeroFinal;
      diag.numeroAutogerado = true;
    } else {
      numeroFinal = String(numero).trim();
      diag.numeroAutogerado = false;
    }

    diag.step = 'check_duplicate';
    const dup = await verificaDuplicata(client, siteId, listNotasId, colMap, hash, fornecedorCNPJ, numeroFinal, serie, chaveAcesso, valor, vencimento, foiAutogerado);
    if (dup) {
      auditRegistrar(user, 'lancamento',
        { tipo: 'nf', numero: numeroFinal },
        'bloqueado',
        { fornecedor: fornecedorCNPJ, valor: valor, motivo: 'duplicidade: ' + (dup.motivo || ''), notaIdConflito: dup.notaId, statusConflito: dup.status, autogerado: foiAutogerado }
      ).catch(function(){});

      context.res = { status: 409, headers: { 'Content-Type': 'application/json' },
        body: { error: 'Duplicidade detectada', motivo: dup.motivo, notaId: dup.notaId, status: dup.status, diag } };
      return;
    }

    diag.step = 'upload_pdf';
    // Padrao Pronep de nomenclatura — ver buildPdfFileName no topo do arquivo
    const finalName = buildPdfFileName({
      numero: numeroFinal,
      fornecedor: fornecedorRazao,
      unidade: unidade,
      valor: valor,
      vencimento: vencimento
    });
    diag.finalName = finalName;
    const folder = `Notas Fiscais/Pendentes/${unidade}/Diretoria ${diretoria}`;
    const uploadPath = `/sites/${siteId}/drive/root:/${encodeURIComponent(folder)}/${encodeURIComponent(finalName)}:/content`;
    diag.uploadPath = uploadPath;
    const uploadResp = await client.api(uploadPath)
      .header('Content-Type', 'application/pdf')
      .put(pdfBuffer);
    diag.driveItemId = uploadResp.id;
    diag.webUrl = uploadResp.webUrl;

    diag.step = 'create_list_item';
    // Title pra NF autogerada inclui descricao (ou observacao como fallback) pra distinguir visualmente.
    // Ex: "NF auto 00001 - Reembolso passagem SP" ou "NF 12345" (manual)
    const descritivoFallback = (descricao || observacao || '').toString().trim().slice(0, 60);
    const title = foiAutogerado
      ? (`NF auto ${numeroFinal}` + (descritivoFallback ? ' - ' + descritivoFallback : '')).slice(0, 80)
      : `NF ${numeroFinal}`;
    // Constroi o objeto com displayNames; buildFieldsObject converte pra internalNames
    // Formata datas como ISO completo (DataVencimento precisa de hora pra SharePoint Date+Time)
    // Se a coluna for soh Date, o SharePoint aceita ISO completo tambem (truncar)
    const isoVenc = (vencimento && vencimento.length === 10) ? (vencimento + 'T00:00:00Z') : vencimento;
    const rawFields = {
      Title:           title,
      NumeroNF:        numeroFinal,
      NumeroAutogerado: foiAutogerado,  // boolean - identifica NFs sem numero formal
      CNPJFornecedor:  fornecedorCNPJ,
      Descricao:       descricao || '',
      Valor:           valor,                       // <-- NUMERO (nao string)
      DataVencimento:  isoVenc,
      Unidade:         unidade,
      Diretoria:       diretoria,
      AprovadorAtual:  aprovador.email,
      Status:          'Lancada',
      LancadoPor:      submitterEmail,
      LancadoEm:       new Date().toISOString(),
      AprovadoEm:      null,                        // <-- null em vez de '' (campo data)
      MotivoRejeicao:  '',
      HashSHA256:      hash,
      ChaveAcesso:     chaveAcesso || '',
      UrlPDF:          uploadResp.webUrl || '',  // formatByType detecta Hyperlink no SP e formata { Url, Description }
      UrlPDFAprovado:  null                       // preenchido na aprovacao
    };
    // Adiciona campos opcionais APENAS se as colunas existirem no SP.
    // Busca case-insensitive (admin pode ter criado 'serie' ou 'Serie' etc).
    function findColCI(name) {
      if (!colMap) return null;
      const lc = String(name).toLowerCase();
      for (const k of Object.keys(colMap)) {
        if (k.toLowerCase() === lc) return k;  // retorna displayName real do SP
      }
      return null;
    }
    const colSerieReal = findColCI('Serie');
    const colObsReal = findColCI('Observacao');
    if (colSerieReal) rawFields[colSerieReal] = serie || '';
    if (colObsReal) rawFields[colObsReal] = observacao || '';
    diag.colunasOpcionais = { colSerie: colSerieReal, colObservacao: colObsReal };

    const itemFieldsRaw = buildFieldsObject(colMap, rawFields);
    // Aplica formatacao por tipo (com log detalhado pra debug)
    const itemFields = {};
    diag.formatLog = {};
    for (const [k, v] of Object.entries(itemFieldsRaw)) {
      const detectedType = (cache.colTypes && cache.colTypes[k]) || 'text';
      const formatted = formatByType(k, v);
      diag.formatLog[k] = {
        colType: detectedType,
        inputValue: v,
        inputType: typeof v,
        outputValue: formatted,
        outputType: typeof formatted
      };
      if (formatted !== undefined) {
        itemFields[k] = formatted;
      }
    }
    diag.itemFieldsUsados = Object.keys(itemFields);
    diag.itemFieldsPayload = itemFields;

    // QUIRK do Graph API: campos do tipo Hyperlink nao podem vir no payload de
    // criacao inicial - precisa criar item primeiro SEM eles, depois PATCH separado.
    // Separa hyperlinks pra patch posterior.
    const hyperlinkFields = {};
    const baseFields = {};
    for (const [k, v] of Object.entries(itemFields)) {
      const t = (cache.colTypes && cache.colTypes[k]) || 'text';
      if (t === 'hyperlink') hyperlinkFields[k] = v;
      else                   baseFields[k] = v;
    }
    diag.hyperlinkFields = Object.keys(hyperlinkFields);

    let itemResp;
    try {
      // Passo 1: cria item SEM hyperlinks
      itemResp = await client
        .api(`/sites/${siteId}/lists/${listNotasId}/items`)
        .post({ fields: baseFields });
      diag.itemId = itemResp.id;
    } catch (createErr) {
      diag.createListError = {
        message: createErr.message,
        statusCode: createErr.statusCode,
        body: createErr.body,
        code: createErr.code
      };
      throw createErr;
    }

    // Passo 2: PATCH separado pra adicionar hyperlinks (se houver)
    if (Object.keys(hyperlinkFields).length > 0) {
      try {
        await client
          .api(`/sites/${siteId}/lists/${listNotasId}/items/${itemResp.id}/fields`)
          .patch(hyperlinkFields);
        diag.hyperlinkPatchOk = true;
      } catch (patchErr) {
        // Esperado falhar — coluna UrlPDF antiga tem tipo nao reconhecido pelo Graph.
        // Fallback abaixo grava em UrlPDFStr (text-multiline novo).
        diag.hyperlinkPatchError = {
          message: patchErr.message,
          statusCode: patchErr.statusCode,
          body: patchErr.body
        };
      }
    }

    // Passo 3: grava URL como STRING em UrlPDFStr (coluna text-multiline criada via Graph
    // como fallback robusto pra coluna UrlPDF antiga que tem tipo invalido).
    try {
      await client
        .api(`/sites/${siteId}/lists/${listNotasId}/items/${itemResp.id}/fields`)
        .patch({ UrlPDFStr: uploadResp.webUrl || '' });
      diag.urlPDFStrOk = true;
    } catch (e) {
      diag.urlPDFStrError = { message: e.message, statusCode: e.statusCode };
    }

    // Dispara notificacao (nao-bloqueante) pro aprovador
    diag.step = 'notify';
    const notifResult = await notificar('lancada', [aprovador.email], {
      itemId: itemResp.id,    // <-- pra gerar links assinados nos botoes
      numero: numeroFinal, fornecedor: fornecedorRazao, valor, vencimento,
      unidade, diretoria, aprovador: aprovador.nome,
      submitter: submitterEmail,
      urlPDF: uploadResp.webUrl,
      autogerado: foiAutogerado,
      descricao: descricao || ''
    });
    diag.notificado = true;
    diag.notifResult = notifResult;  // <-- expoe detalhe (email, teamsAtividade, teamsWebhook) pra debug

    auditRegistrar(user, 'lancamento',
      { tipo: 'nf', id: itemResp.id, numero: numeroFinal, autogerado: foiAutogerado },
      'sucesso',
      {
        fornecedor: fornecedorCNPJ,
        valor: valor,
        vencimento: vencimento,
        unidade: unidade,
        diretoria: diretoria,
        aprovador: aprovador && aprovador.email,
        submitterSource: submitterSource,
        submitterDebug: diag.submitterDebug
      }
    ).catch(function(){});

    context.res = {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: {
        ok: true,
        id: itemResp.id,
        title,
        urlPDF: uploadResp.webUrl,
        aprovador,
        // FIX C: front usa esses 2 valores pra parar de fazer spoofing local
        lancadoPor: submitterEmail,
        submitterSource: submitterSource,
        submitterDebug: diag.submitterDebug,
        diag
      }
    };
  } catch (err) {
    context.log && context.log.error && context.log.error('PostNota error:', err);
    context.res = {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
      body: {
        error: (err && err.message) || String(err),
        statusCode: err && err.statusCode,
        graphBody: err && err.body,
        diag
      }
    };
  }
};

function ctxErr(context, status, msg) {
  context.res = {
    status,
    headers: { 'Content-Type': 'application/json' },
    body: { error: msg }
  };
}
